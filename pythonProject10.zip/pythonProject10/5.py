class InfoNation:
    def __init__(self, name, address, age, phone_number):
        self.name = name
        self.address = address
        self.age = age
        self.phone_number = phone_number

    def get_name(self):
        return self.name

    def get_address(self):
        return self.address

    def get_age(self):
        return self.age

    def get_phone_number(self):
        return self.phone_number

    def set_name(self, name):
        self.name = name

    def set_address(self, address):
        self.address = address

    def set_age(self, age):
        self.age = age

    def set_phone_number(self, phone_number):
        self.phone_number = phone_number


# Пример
person1 = InfoNation("Ваше имя", "Ваш адрес", 25, "+1234567890")
person2 = InfoNation("Друг 1", "Адрес друга 1", 30, "+9876543210")
person3 = InfoNation("Друг 2", "Адрес друга 2", 35, "+1112223334")

print("Персональные данные:")
print("Имя:", person1.get_name())
print("Адрес:", person1.get_address())
print("Возраст:", person1.get_age())
print("Телефонный номер:", person1.get_phone_number())

print()

print("Данные друга 1:")
print("Имя:", person2.get_name())
print("Адрес:", person2.get_address())
print("Возраст:", person2.get_age())
print("Телефонный номер:", person2.get_phone_number())

print()

print("Данные друга 2:")
print("Имя:", person3.get_name())
print("Адрес:", person3.get_address())
print("Возраст:", person3.get_age())
print("Телефонный номер:", person3.get_phone_number())