class Employee:
    def __init__(self, name, employee_id, department, position):
        self.name = name
        self.employee_id = employee_id
        self.department = department
        self.position = position


# пример
employee1 = Employee("Сьюзан Мейрс", 47899, "Бухгалтерия", "Вице-призедент")
employee2 = Employee("Марк Джоунс", 39119, "ИТ", "Программист")
employee3 = Employee("Джой Роджерс", 81774, "Производственный", "Инжинер")

print("Данные сотрудника:")
print("Имя:", employee1.name)
print("Идентификационный номер:", employee1.employee_id)
print("Отдел:", employee1.department)
print("Должность:", employee1.position)

print()

print("Данные сотрудника:")
print("Имя:", employee2.name)
print("Идентификационный номер:", employee2.employee_id)
print("Отдел:", employee2.department)
print("Должность:", employee2.position)

print()

print("Данные сотрудника:")
print("Имя:", employee3.name)
print("Идентификационный номер:", employee3.employee_id)
print("Отдел:", employee3.department)
print("Должность:", employee3.position)