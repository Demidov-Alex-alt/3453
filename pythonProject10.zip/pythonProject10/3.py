class Pet:
    def __init__(self):
        self._name = ""
        self._animal_type = ""
        self._age = 0

    def set_name(self, name):
        self._name = name

    def set_animal_type(self, animal_type):
        self._animal_type = animal_type

    def set_age(self, age):
        self._age = age

    def get_name(self):
        return self._name

    def get_animal_type(self):
        return self._animal_type

    def get_age(self):
        return self._age


pet = Pet()
name = input("Enter pet name: ")
animal_type = input("Enter pet animal type: ")
age = int(input("Enter pet age: "))

pet.set_name(name)
pet.set_animal_type(animal_type)
pet.set_age(age)

print("Pet Information:")
print(f"Name: {pet.get_name()}")
print(f"Animal Type: {pet.get_animal_type()}")
print(f"Age: {pet.get_age()}")