class Book:
    def __init__(self, title, author, publisher):
        self.title = title
        self.author = author
        self.publisher = publisher

    def get_title(self):
        return self.title

    def set_title(self, new_title):
        self.title = new_title

    def get_author(self):
        return self.author

    def set_author(self, new_author):
        self.author = new_author

    def get_publisher(self):
        return self.publisher

    def set_publisher(self, new_publisher):
        self.publisher = new_publisher

    def __str__(self):
        return f"Title: {self.title}, Author: {self.author}, Publisher: {self.publisher}"
