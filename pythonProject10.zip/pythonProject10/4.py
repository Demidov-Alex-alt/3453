class Car:
    def __init__(self, year_model, make):
        self._year_model = year_model
        self._make = make
        self._speed = 0

    def accelerate(self):
        self._speed += 5

    def brake(self):
        self._speed -= 5

    def get_speed(self):
        return self._speed


car = Car("2023", "Toyota")

print("Accelerating...")
for _ in range(5):
    car.accelerate()
    print(f"Current Speed: {car.get_speed()}")

print("Braking...")
for _ in range(5):
    car.brake()
    print(f"Current Speed: {car.get_speed()}")
