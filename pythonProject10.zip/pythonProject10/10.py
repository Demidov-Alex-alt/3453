class RetailItem:
    def __init__(self, description, quantity, price):
        self.description = description
        self.quantity = quantity
        self.price = price


class CashRegister:
    def __init__(self):
        self.items = []

    def purchase_item(self, item):
        self.items.append(item)

    def get_total(self):
        total = 0
        for item in self.items:
            total += item.quantity * item.price
        return total

    def show_items(self):
        for item in self.items:
            print("Описание:", item.description)
            print("Количество:", item.quantity)
            print("Цена за единицу:", item.price)
            print()

    def clear(self):
        self.items = []


def main():
    register = CashRegister()

    while True:
        print("\nМеню:")
        print("1. Добавить товар")
        print("2. Показать выбранные товары")
        print("3. Получить общую стоимость")
        print("4. Очистить список товаров")
        print("5. Выход")

        choice = input("Выберите пункт меню (1-5): ")

        if choice == '1':
            description = input("Введите описание товара: ")
            quantity = int(input("Введите количество: "))
            price = float(input("Введите цену за единицу: "))
            item = RetailItem(description, quantity, price)
            register.purchase_item(item)
            print("Товар добавлен.")
        elif choice == '2':
            print("Выбранные товары:")
            register.show_items()
        elif choice == '3':
            total = register.get_total()
            print("Общая стоимость: $", total)
        elif choice == '4':
            register.clear()
            print("Список товаров очищен.")
        elif choice == '5':
            break
        else:
            print("Некорректный выбор. Пожалуйста, выберите пункт меню от 1 до 5.")


# Запуск
if __name__ == "__main__":
    main()
