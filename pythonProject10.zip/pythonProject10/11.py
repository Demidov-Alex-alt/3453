class Question:
    def __init__(self, question, answer1, answer2, answer3, answer4, correct_answer):
        self.question = question
        self.answer1 = answer1
        self.answer2 = answer2
        self.answer3 = answer3
        self.answer4 = answer4
        self.correct_answer = correct_answer

    def get_question(self):
        return self.question

    def get_answers(self):
        return [self.answer1, self.answer2, self.answer3, self.answer4]

    def get_correct_answer(self):
        return self.correct_answer

    def set_question(self, question):
        self.question = question

    def set_answers(self, answer1, answer2, answer3, answer4):
        self.answer1 = answer1
        self.answer2 = answer2
        self.answer3 = answer3
        self.answer4 = answer4

    def set_correct_answer(self, correct_answer):
        self.correct_answer = correct_answer


question1 = Question("В каком году была основана OpenAI?", "2010", "2015", "2017", "2020", 2)
question2 = Question("Какое самое массовое насекомое на Земле?", "Муравей", "Пчела", "Таракан", "Моль", 3)
question3 = Question("Кто написал роман 'Война и мир'?", "Лев Толстой", "Фёдор Достоевский", "Антон Чехов", "Иван Тургенев", 1)
question4 = Question("Сколько планет в Солнечной системе?", "7", "8", "9", "10", 2)
question5 = Question("Какой столицей является Париж?", "Франция", "Италия", "Германия", "Англия", 1)
question6 = Question("Сколько континентов на Земле?", "5", "6", "7", "8", 3)
question7 = Question("Какое крупнейшее озеро в мире?", "Байкал", "Каспийское море", "Северное Чкалово", "Огоньское", 2)
question8 = Question("Какая самая длинная река в мире?", "Амазонка", "Нил", "Янцзы", "Миссисипи", 1)
question9 = Question("Как называется процесс обратного превращения воды водородом и кислородом?", "Конденсация", "Ионизация", "Дефляция", "Электролиз", 4)
question10 = Question("Кто изображен на купюре в 100 долларов США?", "Бенджамин Франклин", "Авраам Линкольн", "Джордж Вашингтон", "Томас Джефферсон", 1)

questions = [question1, question2, question3, question4, question5,
             question6, question7, question8, question9, question10]

player1_score = 0
player2_score = 0

for i in range(0, len(questions), 2):
    print("Вопрос для игрока 1:")
    print(questions[i].get_question())
    answers = questions[i].get_answers()
    for j in range(len(answers)):
        print(f"{j+1}. {answers[j]}")
    player1_answer = int(input("Введите номер правильного ответа: "))
    if player1_answer == questions[i].get_correct_answer():
        player1_score += 1

    print("Вопрос для игрока 2:")
    print(questions[i+1].get_question())
    answers = questions[i+1].get_answers()
    for j in range(len(answers)):
        print(f"{j+1}. {answers[j]}")
    player2_answer = int(input("Введите номер правильного ответа: "))
    if player2_answer == questions[i+1].get_correct_answer():
        player2_score += 1

print("Результаты:")
print("Игрок 1:", player1_score, "очков")
print("Игрок 2:", player2_score, "очков")
if player1_score > player2_score:
    print("Игрок 1 победил!")
elif player2_score > player1_score:
    print("Игрок 2 победил!")
else:
    print("Ничья!")