class RetailItem:
    def __init__(self, description, quantity, price):
        self.description = description
        self.quantity = quantity
        self.price = price


# пример
item1 = RetailItem("Пиджак", 12, 59.95)
item2 = RetailItem("Дизайнерские джинсы", 40, 34.95)
item3 = RetailItem("Рубашка", 20, 24.95)

print("Данные товара:")
print("Описание:", item1.description)
print("Количество единиц на складе:", item1.quantity)
print("Цена:", item1.price)

print()

print("Данные товара:")
print("Описание:", item2.description)
print("Количество единиц на складе:", item2.quantity)
print("Цена:", item2.price)

print()

print("Данные товара:")
print("Описание:", item3.description)
print("Количество единиц на складе:", item3.quantity)
print("Цена:", item3.price)