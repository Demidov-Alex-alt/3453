class Employee:
    def __init__(self, emp_id, name, department, position):
        self.emp_id = emp_id
        self.name = name
        self.department = department
        self.position = position


employees = {}


def add_employee():
    emp_id = input("Введите идентификационный номер сотрудника: ")
    name = input("Введите имя сотрудника: ")
    department = input("Введите отдел сотрудника: ")
    position = input("Введите должность сотрудника: ")
    employee = Employee(emp_id, name, department, position)
    employees[emp_id] = employee
    print("Сотрудник добавлен в словарь.")


def find_employee():
    emp_id = input("Введите идентификационный номер сотрудника: ")
    if emp_id in employees:
        employee = employees[emp_id]
        print("Имя сотрудника:", employee.name)
        print("Отдел:", employee.department)
        print("Должность:", employee.position)
    else:
        print("Сотрудник с указанным идентификационным номером не найден.")


def update_employee():
    emp_id = input("Введите идентификационный номер сотрудника: ")
    if emp_id in employees:
        employee = employees[emp_id]
        print("Текущие данные сотрудника:")
        print("Имя сотрудника:", employee.name)
        print("Отдел:", employee.department)
        print("Должность:", employee.position)
        name = input("Введите новое имя сотрудника (оставьте пустым, чтобы оставить без изменений): ")
        department = input("Введите новый отдел сотрудника (оставьте пустым, чтобы оставить без изменений): ")
        position = input("Введите новую должность сотрудника (оставьте пустым, чтобы оставить без изменений): ")
        if name:
            employee.name = name
        if department:
            employee.department = department
        if position:
            employee.position = position
        print("Данные сотрудника обновлены.")
    else:
        print("Сотрудник с указанным идентификационным номером не найден.")


def delete_employee():
    emp_id = input("Введите идентификационный номер сотрудника: ")
    if emp_id in employees:
        del employees[emp_id]
        print("Сотрудник удален из словаря.")
    else:
        print("Сотрудник с указанным идентификационным номером не найден.")


def main():
    while True:
        print("\nМеню:")
        print("1. Найти сотрудника")
        print("2. Добавить нового сотрудника")
        print("3. Изменить данные сотрудника")
        print("4. Удалить сотрудника")
        print("5. Выйти из программы")

        choice = input("Выберите пункт меню (1-5): ")

        if choice == '1':
            find_employee()
        elif choice == '2':
            add_employee()
        elif choice == '3':
            update_employee()
        elif choice == '4':
            delete_employee()
        elif choice == '5':
            break
        else:
            print("Некорректный выбор. Пожалуйста, выберите пункт меню от 1 до 5.")


# Запуск
if __name__ == "__main__":
    main()