class Patient:
    def __init__(self, first_name, middle_name, last_name, address, city, region, postal_code, phone,
                 emergency_contact_name, emergency_contact_phone):
        self.first_name = first_name
        self.middle_name = middle_name
        self.last_name = last_name
        self.address = address
        self.city = city
        self.region = region
        self.postal_code = postal_code
        self.phone = phone
        self.emergency_contact_name = emergency_contact_name
        self.emergency_contact_phone = emergency_contact_phone

    def get_full_name(self):
        return f"{self.first_name} {self.middle_name} {self.last_name}"

    def set_full_name(self, first_name, middle_name, last_name):
        self.first_name = first_name
        self.middle_name = middle_name
        self.last_name = last_name


class Procedure:
    def __init__(self, name, date, doctor_name, cost):
        self.name = name
        self.date = date
        self.doctor_name = doctor_name
        self.cost = cost


# пример
patient = Patient("Иван", "Петрович", "Сидоров", "Улица Пушкина 10", "Город", "Область", "12345", "+7 123 456-78-90",
                  "Мария Ивановна", "+7 987 654-32-10")

procedure1 = Procedure("врачебный осмотр", "сегодняшняя", "Ирвин", 250.00)
procedure2 = Procedure("рентгеноскопия", "сегодняшняя", "Джемисон", 500.00)
procedure3 = Procedure("анализ крови", "сегодняшняя", "Смит", 200.00)

print("Информация о пациенте:")
print("ФИО:", patient.get_full_name())
print("Адрес:", patient.address)

print("\nИнформация о процедурах:")
print("1. Название:", procedure1.name)
print("   Дата:", procedure1.date)
print("   Врач:", procedure1.doctor_name)
print("   Стоимость:", procedure1.cost)

total_cost = procedure1.cost + procedure2.cost + procedure3.cost
print("\nОбщая стоимость всех процедур:", total_cost)